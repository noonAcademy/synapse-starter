# @noonacademy/synapse-sdk

Walking skeleton for the Synapse SDK — the thinnest real path from a consumer to noon-citadel's strict `POST /api/events/publish` endpoint. It exposes `createSynapseClient({ baseUrl, appId, appSecret })` whose `publishEvent(type, payload)` HMAC-signs the request and lands a catalogued event, plus (as of `v0.1.2`) `athenaQuery` / `athenaQueryAll` for read-only Athena queries over the same signed path. As of `v0.0.2` it signs via the shared [`@noonacademy/citadel-transport`](../citadel-transport), so the signing scheme is no longer duplicated. Treat anything before `v0.1.0` as unstable.

As of `v0.0.4`, `publishEvent` returns `{ status: 'accepted', eventId } | { status: 'queued' }` and throws `SynapseError` on permanent failures. Transient failures (network error, timeout, `408`/`429`/`5xx`) are enqueued for background retry with exponential backoff (1s → 2s → 4s → … → 30s cap); permanent failures (`400`/`401`/`403`/`422`) are surfaced immediately and never retried, since the server is the source of truth for validity. The queue is bounded (default 1000) and drops the oldest event on overflow via an injectable `logger` seam. Call `client.close()` to stop the background drainer.

As of `v0.1.1`, the client keeps a bounded in-memory ring (default 100) of **terminal** publish outcomes, readable newest-first via `getRecentPublishes({ limit? })`. Each `PublishLogEntry` is `{ type, status, eventId?, error?, attempts, at }`, where `status` is `accepted` (delivered directly or after retries), `failed_permanent` (a non-retryable `publishEvent` throw), or `failed_dropped` (a queued event dropped on permanent failure or overflow). Only terminal states are recorded — `queued`/in-flight is never logged — so a reader never sees a stale pending entry. This is an observability seam only; durable `onPublish`/persistence lands later.

As of `v0.1.2`, the client can also run **app-wide read-only queries** against the Athena data lake, signed with the same HMAC path as `publishEvent`:

- `athenaQuery({ sql, maxRows?, context?, nextToken?, executionId? })` → `Promise<AthenaPage>` POSTs `/api/athena/run` and returns one page: `{ columns: string[]; rows: AthenaRow[]; executionId: string; nextToken?: string }`. `AthenaRow` is `Record<string, string | null>` — Athena returns every value as a string keyed by column name, the one place this SDK uses a dynamic map by design. Reads are synchronous request/response — they are **not** queued or retried. A guard rejection or query failure rejects with `SynapseError` carrying the server's verbatim message (e.g. `Only SELECT (or WITH … SELECT) queries are allowed.`).
- `athenaQueryAll({ sql, maxRows?, context? })` → `AsyncGenerator<AthenaRow>` transparently follows `nextToken` (echoing the `executionId` back, since Athena tokens are execution-scoped) and yields every row across all pages:

  ```ts
  for await (const row of client.athenaQueryAll({ sql: 'SELECT id, name FROM noon2_core.profile' })) {
    console.log(row.id, row.name);
  }
  ```

The query must be a single read-only `SELECT` (or `WITH … SELECT`); a default row limit is applied server-side when you don't specify one.

As of `v0.4.0`, both read calls accept an optional `context` — a short name/title for the read (e.g. `'Attendance dashboard — weekly rollup'`), shown next to the query in the Citadel portal's Data reads view. It travels as the `x-synapse-read-context` header, sanitized to printable ASCII and truncated to 120 chars; omitting it changes nothing.

As of `v0.2.0`, an app can **declare its own event types** and then publish them like any built-in:

- `declareEvent(name, { description, examplePayload })` → `Promise<DeclareEventResult>` POSTs `/api/events/declare`. `name` is positional (mirroring `publishEvent`) and must be lowercase letters / digits / underscores, optionally dot-separated (e.g. `invoice.paid`). You send a **sample payload**, not a schema — the server derives the stored shape from its top-level keys (one optional field per key), so you never hand-author a contract. This is a **synchronous governance decision: it is not queued or retried.** The outcome comes back as data, never a thrown error for the common cases:

  ```ts
  const result = await client.declareEvent('invoice.paid', {
    description: 'A customer invoice was paid in full',
    examplePayload: { invoiceId: 'inv_123', amountCents: 4200, currency: 'SAR' },
  });
  // result.status is one of:
  //   'created'   → { status, name }                       — the type now exists
  //   'suggested' → { status, suggestedType, reason }       — use an existing builtin/app type instead
  //   'blocked'   → { status, reason }                      — obvious junk; fix the name/description
  ```

  Only a transport failure (network error, timeout, malformed body → `400`) rejects with `SynapseError` carrying the server's verbatim message.

  The meaningfulness check **fails open**: if the server-side reviewer is unconfigured, down, or times out, the declaration still proceeds to `created` (the skip is logged server-side, never silently). So a `blocked`/`suggested` outcome is a deliberate decision, not an availability artifact — don't treat declaration as gated on the reviewer being up.

- `publishEvent` is **widened**: built-in types still infer their exact payload (`publishEvent('app_booted', { startedAt })`), and a declared runtime type can now be published with the same call (`publishEvent('invoice.paid', { invoiceId: 'inv_123' })`) without a type error. The runtime path is unchanged — declared events go through the same signed, queued/retried publish as built-ins.

Declare-then-publish in one flow: call `declareEvent` once at startup (or on first use), then `publishEvent` that name whenever the event happens. A declared type only resolves as `valid` for the app that declared it; built-ins always win, so a declaration can never shadow a reserved type.

> v1 retry queue is in-memory only. Events queued during a Citadel outage are lost if the app process restarts before the queue drains. Durable persistence will ship when browser/auto-instrument apps create a real need for it.
