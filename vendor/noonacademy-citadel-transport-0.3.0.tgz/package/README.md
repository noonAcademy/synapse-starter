# @noonacademy/citadel-transport

Wire-level transport — HMAC request signing (`buildHeaders`), the `gql`/`rest` request helpers, and the `CitadelError` type — shared by [`@noonacademy/citadel-client`](../citadel-client) and [`@noonacademy/synapse-sdk`](../synapse-sdk) so the signing scheme lives in exactly one place. Consumers of those packages don't depend on this package directly; it's an internal building block they re-export.
